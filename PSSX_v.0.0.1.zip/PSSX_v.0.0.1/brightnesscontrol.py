import tkinter as tk
from tkinter import Menu
import subprocess
import os

class BrightnessApp:
    def __init__(self, master):
        self.master = master
        self.master.title("P-SSX V.0.0.1")
        self.home_dir = os.path.expanduser("~")
        self.xprofile_path = os.path.join(self.home_dir, ".xprofile")
        self.initial_brightness = self.load_brightness_config()
        self.current_brightness = self.initial_brightness
        self.initial_gamma = self.load_gamma_config()
        self.current_gamma = self.initial_gamma
        self.display_type = self.get_display_type()

        # Frame_Utama
        self.main_frame = tk.Frame(self.master)
        self.main_frame.pack(padx=10, pady=10)

        # Label Display_Type
        self.display_label = tk.Label(self.main_frame, text=f"Display Type: {self.display_type}")
        self.display_label.grid(row=0, column=0, columnspan=2, pady=5)

        # Brightness_Scale
        self.brightness_label = tk.Label(self.main_frame, text="Brightness:")
        self.brightness_label.grid(row=1, column=0, padx=5, pady=5)
        self.brightness_scale = tk.Scale(self.main_frame, from_=0.1, to=1.0, resolution=0.01, orient=tk.HORIZONTAL,
                                         command=self.update_brightness)
        self.brightness_scale.set(self.initial_brightness)
        self.brightness_scale.grid(row=1, column=1, padx=5, pady=5)

        # Gamma_Scale
        self.gamma_label = tk.Label(self.main_frame, text="Gamma:")
        self.gamma_label.grid(row=2, column=0, padx=5, pady=5)
        self.gamma_scale = tk.Scale(self.main_frame, from_=0.1, to=1.0, resolution=0.01, orient=tk.HORIZONTAL,
                                    command=self.update_gamma)
        self.gamma_scale.set(self.initial_gamma)
        self.gamma_scale.grid(row=2, column=1, padx=5, pady=5)

        # Button_Frame
        self.btn_frame = tk.Frame(self.main_frame)
        self.btn_frame.grid(row=3, column=0, columnspan=2, pady=10)

        # Button_Apply
        self.apply_btn = tk.Button(self.btn_frame, text="Apply", width=10, command=self.apply_changes)
        self.apply_btn.grid(row=0, column=0, padx=5)

        # Button_Close
        self.close_btn = tk.Button(self.btn_frame, text="Close", width=10, command=self.master.destroy)
        self.close_btn.grid(row=1, column=0, padx=5)

       # Button_Reset
        self.reset_btn = tk.Button(self.btn_frame, text="Reset", width=10, command=self.reset_changes)
        self.reset_btn.grid(row=0, column=1, padx=5)

    def get_display_type(self):
        try:
            output = subprocess.check_output(["xrandr"]).decode("utf-8")
            for line in output.splitlines():
                if " connected primary" in line:
                    return line.split()[0]
            return "Unknown"
        except Exception as e:
            print("Error:", e)
            return "Unknown"

    def update_brightness(self, brightness):
        self.current_brightness = float(brightness)
        subprocess.Popen(["xrandr", "--output", self.display_type, "--brightness", str(self.current_brightness)])

    def update_gamma(self, gamma):
        self.current_gamma = float(gamma)
        subprocess.Popen(["xgamma", "-gamma", str(self.current_gamma)])

    def apply_changes(self):
        self.save_brightness_config(self.current_brightness)
        self.save_gamma_config(self.current_gamma)
        print("Brightness and Gamma applied")

    def cancel_changes(self):
        self.brightness_scale.set(self.initial_brightness)
        self.current_brightness = self.initial_brightness
        self.gamma_scale.set(self.initial_gamma)
        self.current_gamma = self.initial_gamma

    def reset_changes(self):
        self.brightness_scale.set(1.0)
        self.current_brightness = 1.0
        self.gamma_scale.set(1.0)
        self.current_gamma = 1.0

    def save_brightness_config(self, brightness):
        try:
            with open(self.xprofile_path, "w") as f:
                f.write(f"xrandr --output {self.display_type} --brightness {brightness:.2f}\n")
        except Exception as e:
            print("Error saving brightness config:", e)

    def load_brightness_config(self):
        try:
            with open(self.xprofile_path, "r") as f:
                brightness_line = f.readline().strip()
                brightness = float(brightness_line.split()[-1])
                return brightness
        except Exception as e:
            print("Error loading brightness config:", e)
            return 1.0

    def save_gamma_config(self, gamma):
        try:
            with open(self.xprofile_path, "a") as f:
                f.write(f"xgamma -gamma {gamma:.2f}\n")
        except Exception as e:
            print("Error saving gamma config:", e)

    def load_gamma_config(self):
        try:
            with open(self.xprofile_path, "r") as f:
                lines = f.readlines()
                gamma_line = lines[-1].strip() 
                gamma = float(gamma_line.split()[-1])
                return gamma
        except Exception as e:
            print("Error loading gamma config:", e)
            return 1.0 

def main():
    root = tk.Tk()
    app = BrightnessApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()