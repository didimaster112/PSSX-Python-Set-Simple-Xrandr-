PSSX is a simple & easy to use for setting a brightness and Gamma
if you using Xrandr, you can use it.
=====================================================================
HOW TO USE/Install
=====================================================================
1. Install Python3
2. Install tkinter module for python3
3. Download the PSSX
4. Extract PSSX
5. Launch use Terminal *.sh file or you can excute it
6. Setting for you, apply > close
7. Done

