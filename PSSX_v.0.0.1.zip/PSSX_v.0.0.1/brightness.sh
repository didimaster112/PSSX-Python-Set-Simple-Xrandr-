python brightnesscontrol.py
